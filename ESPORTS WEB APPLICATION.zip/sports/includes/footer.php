
	<div class="copy-right"> 
		<div class="container">
			<p>© cricky</p>
		</div> 
	</div> 
	<!-- //footer -->   
	