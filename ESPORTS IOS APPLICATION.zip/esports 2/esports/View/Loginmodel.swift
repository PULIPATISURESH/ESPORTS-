import Foundation

// MARK: - LoginJSON
struct LoginJSON: Codable {
    let status: Bool
    let message: String
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable {
    let userid, email, mobilenumber, password: String
    let username: String
}
