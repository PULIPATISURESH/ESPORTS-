//
//  ForgotVC.swift
//  esports
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class ForgotVC: UIViewController {
    @IBOutlet weak var savepassword: UIButton!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var newpasswordTF: UITextField!
    @IBOutlet weak var confirmpasswordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func savepassword(_ sender: Any) {
        if  usernameTF.text == "" && emailTF.text == "" && newpasswordTF.text == "" && confirmpasswordTF.text == "" {
        }
        else if usernameTF.text != "" && emailTF.text != "" && newpasswordTF.text != "" && confirmpasswordTF.text != "" {
            registerUser()
        }
    }
    
    func registerUser() {
        let formData: [String: String] = [
            "username": usernameTF.text ?? "",
            "email": emailTF.text ?? "",
            "newpassword": newpasswordTF.text ?? "",
            "confirmpassword": confirmpasswordTF.text ?? ""
        ]
        APIHandler().postAPIValues(type: ForgotModel.self, apiUrl: Constants.serviceType.forgotUrl.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                     self.navigationController?.pushViewController(nextVC, animated: true)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}





