//
//  LoginVC.swift
//  esports
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class LoginVC: UIViewController {
    @IBOutlet weak var userNameTF: UITextField!
    
    @IBOutlet weak var paswordTF: UITextField!
    @IBOutlet weak var login: UIButton!
    
    let apiHandler : APIHandler = APIHandler()
    var apiData : LoginJSON!
    var apiUrl = String()
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = true
    }
    
    @IBAction func loginAc(_ sender: Any) {
        apiUrl = "http://192.168.143.41//ios/login.php?email=\(userNameTF.text ?? "")&password=\(paswordTF.text ?? "")"

        GetAPI()
        
    }
    @IBAction func createAc(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func forgotAc(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ForgotVC") as! ForgotVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    
    func GetAPI(){
        apiHandler.getAPIValues(type: LoginJSON.self, apiUrl: apiUrl, method: "GET") { [self] result in
            switch result {
            case .success(let data):
                self.apiData = data
                print(data)
                let userId = apiData.data.first?.userid
                UserDefaultsManager.shared.saveUserId(userId ?? "")
                DispatchQueue.main.async {
                    let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                    self.navigationController?.pushViewController(nextVC, animated: true)
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {

                let alert = UIAlertController(title: "Warrning", message: "Incorrect Password or ID", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                    print("JSON Error")

                })
                self.present(alert, animated: true, completion: nil)
                }
            }
        
        }
    }
}
