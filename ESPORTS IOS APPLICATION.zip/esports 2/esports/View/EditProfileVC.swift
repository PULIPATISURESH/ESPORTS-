//
//  EditProfileVC.swift
//  esports
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class EditProfileVC: UIViewController {

    @IBOutlet weak var saveprofile: UIButton!
    @IBOutlet weak var home: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        home.addAction(for: .tap) {
            let webVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            self.navigationController?.pushViewController(webVc, animated: true)
        }
        
    }
    @IBAction func saveprofile(_ sender: Any) {
        let webVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(webVc, animated: true)
        
    }
}
