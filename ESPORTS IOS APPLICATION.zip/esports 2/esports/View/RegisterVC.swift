//
//  RegisterVC.swift
//  esports
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class RegisterVC: UIViewController {
    
    @IBOutlet weak var already: UILabel!
    @IBOutlet weak var registerlogin: UIButton!
    @IBOutlet weak var back: UIImageView!

    @IBOutlet weak var userNameTF: UITextField!
    
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var mobileTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        already.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
            
        }
    }
    

    @IBAction func registerlogin(_ sender: Any) {
        if userNameTF.text == "" && emailTF.text == "" && mobileTF.text == "" && passwordTF.text == "" {
        }
        else if userNameTF.text != "" && emailTF.text != "" && mobileTF.text != "" && passwordTF.text != "" {
            registerUser()
        }
        
        
//        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
//        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    
    func registerUser() {
        let formData: [String: String] = [
            "username": userNameTF.text ?? "",
            "mobilenumber": mobileTF.text ?? "",
            "email": emailTF.text ?? "",
            "password": passwordTF.text ?? ""
        ]
        APIHandler().postAPIValues(type: SignUpJson.self, apiUrl: Constants.serviceType.signUpUrl.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(nextVC, animated: true)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}
