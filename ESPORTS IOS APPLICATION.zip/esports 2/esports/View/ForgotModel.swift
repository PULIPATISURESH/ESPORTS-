//
//  ForgotModel.swift
//  esports
//
//  Created by SAIL on 10/10/23.
//


import Foundation

// MARK: - Welcome
struct ForgotModel : Codable {
    let status: Bool
    let message: String
}
