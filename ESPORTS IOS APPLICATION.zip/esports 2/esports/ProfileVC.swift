//
//  ProfileVC.swift
//  esports
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class ProfileVC: UIViewController {
    
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var mobilenumberLbl: UILabel!
    
    @IBOutlet weak var headusernameLbl: UILabel!
    
    
    let apiHandler : APIHandler = APIHandler()
    var apiData : ProfileJSON!
    var apiUrl = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
        

        home.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        GetAPI()

    }

    
    func GetAPI(){
        
        apiHandler.getAPIValues(type: ProfileJSON.self, apiUrl: Constants.serviceType.ProfileAPI, method: "GET") { [self] result in
            switch result {
            case .success(let data):
                self.apiData = data
                print(data)
                DispatchQueue.main.async {
                    userNameLbl.text = apiData.data.username
                    emailLbl.text = apiData.data.email
                    mobilenumberLbl.text = apiData.data.mobilenumber
                    headusernameLbl.text = apiData.data.username
                }
                
                
            case .failure(let error):
                print(error)
                
            }
        }
        
    }
}
